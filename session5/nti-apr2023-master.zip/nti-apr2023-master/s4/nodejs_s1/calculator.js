class Calculator{
    static add = ( x , y ) => x + y
    static sub = ( x , y ) => x - y
    static mul = ( x , y ) => x * y
    static div = ( x , y ) => x / y
}
module.exports = Calculator

